//Timer as a counter in different modes
#include <REG51.H>
void count()
{

		TH0=0x00;
		TL0=0x00;
//		TH0=0xFF;//counting 5 pulses
//		TL0=0xFA;
		TR0=1;//start timer
		while(TF0==0);
		TR0=0;//stop timer 
		TF0=0;//clear overflow
		//TCON=0x00;//stop timer and cler overflow using TCON
}
void main()
{
	//		TMOD=0x04;//mode 0 of timer 0 is selected (as 13 bit counter)
		TMOD=0x05;//mode 1 of timer 0 is selected  (as 16 bit counter)
//		TMOD=0x06;//mode 2 of timer 0 is selected (as 8 bit auto reload counter) 
//		TMOD=0x07;//mode 3 of timer 0 is selected (as split mode counter)
	while(1)
	{
		count();
	}
}