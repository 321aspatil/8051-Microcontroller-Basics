//timer as a timer in different modes
#include <REG51.H>
void delay()
{
		TH0=0x00;
		TL0=0x00;
		TR0=1;//start timer
		while(TF0==0);
		TR0=0;//stop timer 
		TF0=0;//clear overflow
		//TCON=0x00;//stop timer and cler overflow using TCON
}
void main()
{
//		TMOD=0x00;//mode 0 of timer 0 is selected
		TMOD=0x01;//mode 1 of timer 0 is selected
//		TMOD=0x02;//mode 2 of timer 0 is selected
//		TMOD=0x03;//mode 3 of timer 0 is selected
	while(1)
	{
		delay();
	}
}