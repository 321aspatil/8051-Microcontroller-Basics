#include <REG51.H>
sbit LED=P1^1;
void time_delay()
{
	TH0=0;
	TL0=0;
	TR0=1;
	while(TH0<=0xB4);// && TL0<=0x03);
	TR0=0;
}
void main()
{
	TMOD=0x01;
	LED=0;
	while(1)
	{
		LED=~LED;
		time_delay();
	}
}