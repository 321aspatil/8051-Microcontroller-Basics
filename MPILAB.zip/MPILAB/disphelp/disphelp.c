#include <REG51.H>
sfr Port3_Data=0XA0;

unsigned char msg[4]={0x76,0X79,0X38,0X73};
unsigned char enb[4]={0X0E,0X0D,0X0B,0X07};

void msdelay(unsigned int time){
	unsigned int i,j;
	for(i=0;i<time;i++){
		for(j=0;i<1275;j++);
	}
}

void main(){
	unsigned int k=0;
	while(1){
		k=k%4;
		P3=enb[k];
		Port3_Data=msg[k];
		msdelay(5);
		k++;
	}
}
