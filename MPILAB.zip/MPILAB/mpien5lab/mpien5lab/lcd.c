#include <REG51.H>
sfr LCD_DATA=0XB0;
sbit RS=P2^0;
sbit RW=P2^1;
sbit E =P2^2;
void msdelay(unsigned int time){
	unsigned int i,j;
	for(i=0;i<time;i++){
		for(j=0;j<1275;j++);
	}
}
void lcd_cmd(unsigned char command){
	LCD_DATA=command;
	RS=0;// for command
	RW=0;
	E=1;
	msdelay(1);
	E=0;
}
void lcd_data(unsigned char disp_data){
	LCD_DATA=disp_data;
	RS=1;// for data
	RW=0;
	E=1;
	msdelay(1);
	E=0;
}
void lcd_init(){
	lcd_cmd(0X38);//for using 2 lines of 5*7 matrix of LCD
	msdelay(1);
	lcd_cmd(0X0c);
	msdelay(10);
	lcd_cmd(0X80);
	msdelay(10);
	
}
void main(){
	unsigned char a[]="MPI-8051";
	int i=0;
	lcd_init();
	while(a[i]!='\0'){
		lcd_data(a[i]);
		i++;
		msdelay(50);
	}
}
