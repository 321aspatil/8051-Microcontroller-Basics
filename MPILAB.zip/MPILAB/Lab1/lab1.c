#include<REG51.H>

sbit LED=P1^0;

void delay(){
	unsigned int i;
	for(i=0;i<255;i++);
}
void main(){
	while(1){
	LED=1;
	delay();
	LED=0;
	delay();
	}
}