//sine wave 1
//#include <REG51.H>
//sfr DAC_DATA=0xA0;
//void main()
//{
//	unsigned char SINE[12]={128,191,238,255,238,191,128,64,17,0,17,64};
//	unsigned char i;
//	while(1)
//	{
//		for(i=0;i<12;i++)
//		{
//			DAC_DATA=SINE[i];
//		}
//	}
//}

//sine wave 2
//#include <REG51.H>
//sfr DAC_DATA=0xA0;
//void main()
//{
//	unsigned char SINE[36]={128,150,171,191,210,225,238,247,253,255,253,247,238,225,210,191,171,150,128,105,84,64,46,30,17,8,2,0,2,8,17,30,46,64,84,105};
//	unsigned char i;
//	while(1)
//	{
//		for(i=0;i<36;i++)
//		{
//			DAC_DATA=SINE[i];
//		}
//	}
//}

//sawtooth wave form 1
//#include <REG51.H>
//sfr DAC_DATA=0xA0;
//void main()
//{
//	unsigned char i;
//	while(1)
//	{
//		for(i=0;i<255;i++)
//		{
//			DAC_DATA=i;
//		}
//	}
//}


//sawtooth wave form 2
//#include <REG51.H>
//sfr DAC_DATA=0xA0;
//void main()
//{
//	unsigned char i;
//	while(1)
//	{
//		for(i=255;i>=0;i--)
//		{
//			DAC_DATA=i;
//		}
//	}
//}


//triangular wave
//#include <REG51.H>
//sfr DAC_DATA=0xA0;
//void main()
//{
//	unsigned char i;
//	while(1)
//	{
//		for(i=0;i<255;i++)
//		{
//			DAC_DATA=i;
//		}
//		for(i=255;i>0;i--)
//		{
//			DAC_DATA=i;
//		}
//	}
//}

