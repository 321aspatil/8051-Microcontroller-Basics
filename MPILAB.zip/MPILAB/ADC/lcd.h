sfr LCD_DATA=0XA0;
sbit RS=P0^0;
sbit RW=P0^1;
sbit E =P0^2;
void lmsdelay(unsigned int time){
	unsigned int i,j;
	for(i=0;i<time;i++){
		for(j=0;j<1275;j++);
	}
}
void lcd_cmd(unsigned char command){
	LCD_DATA=command;
	RS=0;// for command
	RW=0;
	E=1;
	lmsdelay(1);
	E=0;
}
int lcd_data(unsigned char disp_data){
	LCD_DATA=disp_data;
	RS=1;// for data
	RW=0;
	E=1;
	lmsdelay(1);
	E=0;
	return 0;
}
void lcd_init(){
	lcd_cmd(0X38);//for using 2 lines of 5*7 matrix of LCD
	lmsdelay(1);
	lcd_cmd(0X0c);
	lmsdelay(10);
	lcd_cmd(0X80);
	lmsdelay(10);
}
