/*#include <REG51.H>
sbit LED=P1^1;
void time_delay()
{
	TH0=0;
	TL0=0;
	TR0=1;
	//while(TH0<=0xB4);//50ms
	while(TH0<=0x24);//10ms
	TR0=0;
}
void main()
{
	TMOD=0x01;
	LED=0;
	while(1)
	{
		LED=~LED;
		time_delay();
	}
}
*/


/*
#include <REG51.H>
void timer_int() interrupt 1
{
	LED=~LED;
}
void main()
{
	IF=0x82;
	TMOD=0x01;
	LED=0;
	while(1)
	{
		
	}
}
*/