#include <REG51.H>
/*sbit LED=P1^0;
void main(){
	unsigned char i;
	while(1){
		LED=~LED;
		for(i=0;i<100;i++);
	}
}
*/
sbit LED=P1^0;
void delay(unsigned int j){
	unsigned int i;
	for(i=0;i<j;i++);
}
void main(){
	while(1){//for(;;)
		LED=0;
		delay(100);
		LED=1;
		delay(200);
	}
}
