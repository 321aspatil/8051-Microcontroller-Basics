#include<REG51.h>
sbit LED=P2^0;
sbit SW=P1^0;
void main(){
	while(1){
		if(SW==0){
			LED=1;
		}
		else{
			LED=0;
		}
	}
}